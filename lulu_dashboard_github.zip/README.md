
# Lulu Hypermarket — Synthetic Sales Dashboard

This repository contains a small synthetic transactional dataset (50 rows) and a Streamlit dashboard that demonstrates how to analyze sales by demographic filters.

## Files
- `lulu_transactions_50rows.csv` - Synthetic transactional data
- `app.py` - Streamlit dashboard. Run with: `streamlit run app.py`
- `README.md` - This file
- `requirements.txt` - Suggested Python packages

## Notes
- Data is synthetic and randomly generated for demo purposes.
- The Streamlit app includes filters for store, gender, nationality, category, payment method and age range.
